Graduated since 1992 in interior architecture (Parsons School of Design, New York City), I carry out many projects in many different areas: apartments, houses, offices, restaurants.

I am particularly recognized for my renovations of Haussmann-style apartments where I take up their ergonomics to make them functional for modern life while preserving their cachet of yesteryear.