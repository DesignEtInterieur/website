# Architecture d'Intérieur

> *Notre passion à votre service*

---

Diplômé depuis 1992 en architecture d'intérieur (Parsons School of Design, New-York city), je réalise de nombreux projets dans de nombreux domaines différents : appartements, maisons, bureaux, restaurants.

Je suis plus particulièrement reconnu pour mes rénovations d'appartements de type haussmanniens où je reprends leur ergonomie pour les rendre fonctionnels à la vie moderne tout en préservant leur cachet d'autrefois.