# L'expérience du cinéma dans votre intérieur

>> *Une passion qui nous suit depuis 1996*

---

Après avoir travaillé dans les bureaux d'étude de Disney en Floride, ainsi que chez THX "Lucasfilms" en Californie, nous avons créé notre première entreprise en 1996 dédiée à l'intégration des nouvelles technologies, adaptées aux espaces d'intérieur particuliers et professionnels.

Regroupant les domaines liés à la gestion de lumière (LUTRON), l'audio-vidéo et la domotique (AMX, CONTROL4), nous avons depuis réalisé des dizaines de projets partout dans le monde.